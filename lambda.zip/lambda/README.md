Contents:
- `index.js` is the source for the lambda function
- `out` is [`dino-core`](https://github.com/hassy/dino-core) transpiled to ES5 with Babel (`dino-core` itself is a stripped down version of [`artillery-core`](https://github.com/shoreditch-ops/artillery-core))
- `dino_lambda.zip` is the above zipped up for convenience - this is the zip that gets uploaded to Lambda
